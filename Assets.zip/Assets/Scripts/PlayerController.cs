using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float forwardSpeed = 5;
    public float horizontalSpeed = 5;
    public static bool allowedToMove = true;
    public GameObject player;
    public GameObject shield;
    public GameObject pausePanel;
    public static bool greenPowerUpFlag = false;
    public static bool bluePowerUpFlag = false;
    public static bool redPowerUpFlag = false;
    public static int obstacleCount = 0;
    public static bool pauseFlag = false;
    public static int escapeCounter = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            escapeCounter++;
            if ((escapeCounter % 2) != 0)
            {
                pauseFlag = true;
                allowedToMove = false;
                pausePanel.gameObject.SetActive(true);
            }
            if ((escapeCounter % 2) == 0)
            {
                pauseFlag = false;
                allowedToMove = true;
                pausePanel.gameObject.SetActive(false);
            }
        }

        if (allowedToMove)
        {
            transform.Translate(Vector3.forward * forwardSpeed * Time.deltaTime, Space.World);

            if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
            {
                if (this.gameObject.transform.position.x < RulesController.rightBoundary)
                {
                    transform.Translate(Vector3.right * horizontalSpeed * Time.deltaTime);
                }
            }

            if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
            {
                if (this.gameObject.transform.position.x > RulesController.leftBoundary)
                {
                    transform.Translate(Vector3.left * horizontalSpeed * Time.deltaTime);
                }
            }

            if (Input.GetKey(KeyCode.J) && ScoreController.redOrbCountStatic == 5)
            {
                Material mat = player.GetComponent<Renderer>().material;
                mat.SetColor("_Color", Color.red);
                ScoreController.redOrbCountStatic--;
            }

            if (Input.GetKey(KeyCode.K) && ScoreController.greenOrbCountStatic == 5)
            {
                Material mat = player.GetComponent<Renderer>().material;
                mat.SetColor("_Color", Color.green);
                ScoreController.greenOrbCountStatic--;
            }

            if (Input.GetKey(KeyCode.L) && ScoreController.blueOrbCountStatic == 5)
            {
                Material mat = player.GetComponent<Renderer>().material;
                mat.SetColor("_Color", Color.blue);
                ScoreController.blueOrbCountStatic--;
            }

            Material mat2 = player.GetComponent<Renderer>().material;
            if (mat2.GetColor("_Color") == Color.blue && Input.GetKeyDown(KeyCode.Space))
            {
                if(!shield.gameObject.activeSelf)
                {
                    ScoreController.blueOrbCountStatic--;
                    shield.gameObject.SetActive(true);
                    bluePowerUpFlag = true;
                }

                if (bluePowerUpFlag)
                {
                    StartCoroutine(BlueShield());
                }



                IEnumerator BlueShield()
                {
                    yield return new WaitForSeconds(20);
                    bluePowerUpFlag = false;

                }

            }

            if (mat2.GetColor("_Color") == Color.red && Input.GetKeyDown(KeyCode.Space))
            {
                ScoreController.redOrbCountStatic--;
                redPowerUpFlag= true;

                if (redPowerUpFlag)
                {
                    StartCoroutine(NukeHit());
                }



                IEnumerator NukeHit()
                {
                    yield return new WaitForSeconds(10);
                    redPowerUpFlag = false;

                }

            }

            if (mat2.GetColor("_Color") == Color.green && Input.GetKeyDown(KeyCode.Space))
            {
                ScoreController.greenOrbCountStatic--;
                greenPowerUpFlag= true;
            }

            Material mat3 = player.GetComponent<Renderer>().material;
            if (mat3.GetColor("_Color") == Color.red)
            {


                if (ScoreController.redOrbCountStatic == 0)
                {

                    mat3.SetColor("_Color", Color.white);
                    PlayerController.greenPowerUpFlag = false;
                    PlayerController.bluePowerUpFlag = false;
                    PlayerController.redPowerUpFlag = false;
                    shield.gameObject.SetActive(false); 

                }
            }
        }
    }
}
