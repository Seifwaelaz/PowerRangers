using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PartitionsController : MonoBehaviour
{
    public GameObject[] partitions;
    public bool partitionFlag = false;
    public int partitionSelect;
    public int newPartitionZ = 15;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(!partitionFlag)
        {
            partitionFlag = true;
            StartCoroutine(CreateNewPartition());
        }
    }

    IEnumerator CreateNewPartition()
    {
        if (PlayerController.redPowerUpFlag)
        {
            partitionSelect = Random.Range(5, 7);
        }
        else
        {
            partitionSelect = Random.Range(0, 5);
        }
        Instantiate(partitions[partitionSelect], new Vector3(0, 0, newPartitionZ), Quaternion.identity);
        newPartitionZ = newPartitionZ + 15;
        yield return new WaitForSeconds(2);
        partitionFlag= false;
    }
}
