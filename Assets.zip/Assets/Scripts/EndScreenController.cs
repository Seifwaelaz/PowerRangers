using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EndScreenController : MonoBehaviour
{
    public GameObject redOrbsPanel;
    public GameObject greenOrbsPanel;
    public GameObject blueOrbsPanel;
    public GameObject scorePanel;
    public GameObject pausePanel;
   // public GameObject livesPanel;
    public GameObject ending;
    public static bool endGameFlag = false;

    // Start is called before the first frame update
    void Start()
    {
        ending.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(endGameFlag)
        {
            EndGame();
        }
    }

    public void EndGame()
    {
        redOrbsPanel.SetActive(false);
        greenOrbsPanel.SetActive(false);
        blueOrbsPanel.SetActive(false);
        scorePanel.SetActive(false);
        pausePanel.SetActive(false);
        //livesPanel.SetActive(false);    
        ending.SetActive(true);
        PlayerController.allowedToMove = false;

    }

    public void ResumeGame()
    {
        PlayerController.pauseFlag = false;
        PlayerController.allowedToMove = true;
        pausePanel.gameObject.SetActive(false);
        PlayerController.escapeCounter++;
    }

    public void RestartGame()
    {
        endGameFlag = false;
        SceneManager.LoadScene(1);
        redOrbsPanel.SetActive(true);
        greenOrbsPanel.SetActive(true);
        blueOrbsPanel.SetActive(true);
        scorePanel.SetActive(true);
        pausePanel.SetActive(false);
       // livesPanel.SetActive(true); 
        ending.SetActive(false);
        PlayerController.allowedToMove = true;
        ScoreController.blueOrbCountStatic = 0;
        ScoreController.greenOrbCountStatic = 0;
        ScoreController.redOrbCountStatic = 0;
        ScoreController.finalScoreStatic = 0;
        ScoreController.scoreCountStatic = 0;
        PlayerController.bluePowerUpFlag = false;
        PlayerController.greenPowerUpFlag = false;
        PlayerController.redPowerUpFlag= false;
        PlayerController.obstacleCount = 0;
        PlayerController.pauseFlag= false;
        //ScoreController.livesStatic = 3;
    }

    public void GoToMenu()
    {
        SceneManager.LoadScene(0);
        endGameFlag = false;
        redOrbsPanel.SetActive(true);
        greenOrbsPanel.SetActive(true);
        blueOrbsPanel.SetActive(true);
        scorePanel.SetActive(true);
        pausePanel.SetActive(false);    
        //livesPanel.SetActive(true);
        ending.SetActive(false);
        PlayerController.allowedToMove = true;
        ScoreController.blueOrbCountStatic = 0;
        ScoreController.greenOrbCountStatic = 0;
        ScoreController.redOrbCountStatic = 0;
        ScoreController.finalScoreStatic = 0;
        ScoreController.scoreCountStatic = 0;
        PlayerController.bluePowerUpFlag = false;
        PlayerController.greenPowerUpFlag = false;
        PlayerController.redPowerUpFlag = false;
        PlayerController.obstacleCount = 0;
        PlayerController.pauseFlag = false;
        // ScoreController.livesStatic = 3;
    }
}
