using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleController : MonoBehaviour
{
    public AudioSource obstacleSound;
    public GameObject player;
    public GameObject shield;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {

        //ScoreController.scoreCountStatic -= 1000;
        obstacleSound.Play();
        this.gameObject.SetActive(false);
        Material mat = player.GetComponent<Renderer>().material;
        
        //PlayerController.allowedToMove = false;
       
        if (mat.GetColor("_Color") == Color.blue || mat.GetColor("_Color") == Color.red)
        {
            if(PlayerController.bluePowerUpFlag)
            {
                PlayerController.obstacleCount++;
                shield.SetActive(false);
            }
            if (PlayerController.obstacleCount > 1)
            {
                mat.SetColor("_Color", Color.white);
                PlayerController.greenPowerUpFlag = false;
                PlayerController.bluePowerUpFlag = false;
                PlayerController.redPowerUpFlag = false;
            }
        }
        else
        {
            EndScreenController.endGameFlag = true;
        }
        
        
        
        
        
    }

}
