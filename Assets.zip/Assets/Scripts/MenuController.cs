using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine.UI;


public class MenuController : MonoBehaviour
{
    public AudioSource menuMusic;
    public Button htpButton;
    public Button creditsButton;
    public Button muteButton;

    public Button startGameButton;
    public Button OptionsButton;
    public Button quitButton;

    public Button backToMenuButton;
    public Button backToOptionsButton;

    public TMP_Text gameTitle;
    public TMP_Text creditsText;
    public TMP_Text htpText;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void StartGame()
    {
        //EndScreenController.endGameFlag = false;
        //EndScreenController.redOrbsPanel.SetActive(true);
        //EndScreenController.greenOrbsPanel.SetActive(true);
        //EndScreenController.blueOrbsPanel.SetActive(true);
        //EndScreenController.scorePanel.SetActive(true);
        //EndScreenController.ending.SetActive(false);
        //PlayerController.allowedToMove = true;
        //ScoreController.blueOrbCountStatic = 0;
        //ScoreController.greenOrbCountStatic = 0;
        //ScoreController.redOrbCountStatic = 0;
        //ScoreController.finalScoreStatic = 0;
        //ScoreController.scoreCountStatic = 0;
        
        SceneManager.LoadScene(1);
        

    }

    public void GoToOptions()
    {
        //StartMenuMusic();
        gameTitle.gameObject.SetActive(false);
        startGameButton.gameObject.SetActive(false);
        OptionsButton.gameObject.SetActive(false);
        quitButton.gameObject.SetActive(false);
        creditsText.gameObject.SetActive(false);
        htpText.gameObject.SetActive(false);
        backToOptionsButton.gameObject.SetActive(false);

        htpButton.gameObject.SetActive(true);
        creditsButton.gameObject.SetActive(true);
        muteButton.gameObject.SetActive(true);
        backToMenuButton.gameObject.SetActive(true);
        //SceneManager.LoadScene(2);
    }

    public void GoToHowToPlay()
    {
        //StartMenuMusic();
        creditsButton.gameObject.SetActive(false);
        htpButton.gameObject.SetActive(false);  
        muteButton.gameObject.SetActive(false);
        backToMenuButton.gameObject.SetActive(false);

        htpText.gameObject.SetActive(true);
        backToOptionsButton.gameObject.SetActive(true);
        //SceneManager.LoadScene(3);
    }


    public void GoToCredits()
    {
        //StartMenuMusic();
        //SceneManager.LoadScene(4);
        creditsButton.gameObject.SetActive(false);
        htpButton.gameObject.SetActive(false);  
        muteButton.gameObject.SetActive(false);
        backToMenuButton.gameObject.SetActive(false);

        creditsText.gameObject.SetActive(true); 
        backToOptionsButton.gameObject.SetActive(true); 
    }

    public void QuitGame()
    {
        //SceneManager.LoadScene(4);
    }

    public void GoToMainMenu()
    {
        OptionsButton.gameObject.SetActive(true);
        quitButton.gameObject.SetActive(true);  
        startGameButton.gameObject.SetActive(true);
        gameTitle.gameObject.SetActive(true);

        backToMenuButton.gameObject.SetActive(false);
        creditsButton.gameObject.SetActive(false);
        htpButton.gameObject.SetActive(false);
        muteButton.gameObject.SetActive(false); 

        
        //SceneManager.LoadScene(0);
        //if (menuCounter > 1)
        //{
         //   menuMusic.Pause();
        //}
    }

    public void MuteButton()
    {
        menuMusic = GetComponent<AudioSource>();
        if (menuMusic.mute)
        {
            menuMusic.mute = false;
        }
        else
        {
            menuMusic.mute = true;
        }
    }

    //public void StartMenuMusic()
    //{
     //   if (menuMusic.isPlaying)
      //  {
       //     return;
       // }
       // menuMusic.Play();
    //}

    //public void StopMenuMusic()
    //{
     //   menuMusic.Stop();
    //}

    //public void Awake()
    //{
      //  if (!startedPlaying && SceneManager.GetActiveScene().buildIndex == 0)
       // {
         //   DontDestroyOnLoad(menuMusic);
          //  menuMusic = GetComponent<AudioSource>();
        //}
    //}
}
