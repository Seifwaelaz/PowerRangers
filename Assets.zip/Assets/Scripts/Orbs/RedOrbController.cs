using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RedOrbController : MonoBehaviour
{
    public int rotationVelocity = 1;
    public AudioSource orbSound;
    public GameObject player;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(0, rotationVelocity, 0, Space.World);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (ScoreController.redOrbCountStatic < 5)
        {

            if (PlayerController.greenPowerUpFlag)
            {
                ScoreController.redOrbCountStatic += 2;
                if (ScoreController.redOrbCountStatic > 5)
                {
                    ScoreController.redOrbCountStatic = 5;
                }
            }
            else
            {
                ScoreController.redOrbCountStatic++;
            }

        }                
            

            if (PlayerController.greenPowerUpFlag)
            {
                ScoreController.scoreCountStatic += 5;
                ScoreController.finalScoreStatic += 5;
                //ScoreController.redOrbCountStatic += 2;
                PlayerController.greenPowerUpFlag= false;
            }
            else
            {
                ScoreController.scoreCountStatic += 1;
                ScoreController.finalScoreStatic += 1;
            }



        
        
        
        orbSound.Play();
        this.gameObject.SetActive(false);
    }

}
