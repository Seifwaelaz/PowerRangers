using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenOrbController : MonoBehaviour
{
    public int rotationVelocity = 1;
    public AudioSource orbSound;
    public GameObject player;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(0, rotationVelocity, 0, Space.World);
    }

    private void OnTriggerEnter(Collider other)
    {
        
            Material mat = player.GetComponent<Renderer>().material;
            if (mat.GetColor("_Color") == Color.green)
            {
                if (PlayerController.greenPowerUpFlag)
                {
                    ScoreController.scoreCountStatic += 10;
                    ScoreController.finalScoreStatic += 10;
                    PlayerController.greenPowerUpFlag = false;
                    
                }
                else
                {
                    ScoreController.scoreCountStatic += 2;
                    ScoreController.finalScoreStatic += 2;

                }
                

                if (ScoreController.greenOrbCountStatic == 0)
                {

                    mat.SetColor("_Color", Color.white);
                    PlayerController.greenPowerUpFlag = false;
                    PlayerController.redPowerUpFlag= false;
                    PlayerController.bluePowerUpFlag= false;

                }
            }

            else
            {
                if (ScoreController.greenOrbCountStatic < 5)
                {
                    ScoreController.greenOrbCountStatic++;
                }
            
    

        }
        //ScoreController.scoreCountStatic += 10;
        //ScoreController.finalScoreStatic += 10;
        orbSound.Play();
        this.gameObject.SetActive(false);
    }

}
