using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class ScoreController : MonoBehaviour
{
    public static int redOrbCountStatic;
    public static int greenOrbCountStatic;
    public static int blueOrbCountStatic;
    public static int scoreCountStatic;
    public static int finalScoreStatic;
   // public static int livesStatic = 3;
    public TMP_Text redOrbCount;
    public TMP_Text greenOrbCount;
    public TMP_Text blueOrbCount;
    public TMP_Text scoreCount;
    public TMP_Text finalScore;
   // public TMP_Text livesText;
    public bool scoreFlag = false;
    public int runningScore;
    public float scoreStop = 0.2f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        redOrbCount.SetText(redOrbCountStatic + "");
        greenOrbCount.SetText(greenOrbCountStatic + "");
        blueOrbCount.SetText(blueOrbCountStatic + "");
      //  livesText.SetText(livesStatic + "");


        if (!scoreFlag)
        {
            scoreFlag = true;
            StartCoroutine(IncreaseScore());
        }

    }

    IEnumerator IncreaseScore()
    {
        if (EndScreenController.endGameFlag == false && PlayerController.pauseFlag == false)
        {
            runningScore = runningScore + 1;
            scoreCountStatic = scoreCountStatic + 1;
            finalScoreStatic = finalScoreStatic + 1;
            finalScore.SetText(finalScoreStatic + "");
            scoreCount.SetText(scoreCountStatic + "");

            

            yield return new WaitForSeconds(scoreStop);
            scoreFlag = false;
        }
    }



    
}
